PAKET BUKTI PAPER TRAIL

Isi:
  pack.json   paket bukti (rantai catatan, tanda tangan saksi, jangkar waktu)
  files/      berkas lampiran, diberi nama sesuai kode SHA-256 isinya

Cara memeriksa (tanpa akun, tanpa internet):
  npx paper-trail-verify paket.zip --roots akar-tsa.pem
atau buka halaman /verify Paper Trail (pemeriksaan berjalan di browser, paket tidak dikirim),
atau ikuti docs/VERIFY.md untuk memeriksa hanya dengan Python dan OpenSSL.

Paper Trail membantu membuktikan bahwa catatan tidak diubah setelah dibuat dan kapan catatan itu ada.
Ini bukan nasihat hukum dan tidak menjamin penerimaan sebagai alat bukti. Konsultasikan dengan pendamping hukum.
