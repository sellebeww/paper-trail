PAKET BUKTI PAPER TRAIL

Isi:
  pack.json   paket bukti (rantai catatan, tanda tangan saksi, jangkar waktu)
  files/      berkas lampiran, diberi nama sesuai kode SHA-256 isinya

Cara memeriksa (tanpa akun, tanpa internet):
  papertrail-verify paket.zip --roots akar-tsa.pem
atau tempel pack.json di halaman verifikasi Paper Trail.

Paper Trail membantu membuktikan bahwa catatan tidak diubah setelah dibuat dan kapan catatan itu ada.
Ini bukan nasihat hukum dan tidak menjamin penerimaan sebagai alat bukti. Konsultasikan dengan pendamping hukum.
